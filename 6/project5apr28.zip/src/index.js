// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>
//Woody Hwang

const sliderForm = document.querySelector(".js-slider"),
  sliderInput = sliderForm.querySelector("input"),
  sliderText = sliderForm.querySelector("h4");

const numberForm = document.querySelector(".js-number"),
  numberInput = numberForm.querySelector("input");

const resultsDiv = document.querySelector(".js-results"),
  numChoice = resultsDiv.querySelector("#choice"),
  numResult = resultsDiv.querySelector("#result");

const HIDING_CN = "hiding";

function paintChoice(numberNum, rand, resultText) {
  numberInput.value = numberNum;
  numChoice.innerText = `You choose: ${numberNum}, the machine chose: ${rand}`;
  numResult.innerText = `You ${resultText}!`;
}

function paintSlider(text) {
  sliderInput.value = text;
  sliderText.innerText = `Generating a Number between 0 and ${text}`;
}

function resultGenerator(numberNum, rand) {
  let numA = numberNum;
  let numB = JSON.stringify(rand);
  if (numA === numB) {
    return "win";
  } else {
    return "lose";
  }
}
function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function machineChoice(numberNum, sliderNum) {
  let rand = randomNumber(0, sliderNum);
  let resultText = resultGenerator(numberNum, rand);
  paintChoice(numberNum, rand, resultText);
}

function handleSlidbar(event) {
  event.preventDefault();
  const sliderNum = sliderInput.value;
  paintSlider(sliderNum);
}

function handleSubmit(event) {
  resultsDiv.classList.remove(HIDING_CN);
  event.preventDefault();
  const numberNum = numberInput.value;
  numberInput.value = "";
  const sliderNum = sliderInput.value;
  machineChoice(numberNum, sliderNum);
}

function init() {
  numberForm.addEventListener("submit", handleSubmit);
  sliderForm.addEventListener("click", handleSlidbar);
}
init();
